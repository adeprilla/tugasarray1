-- phpMyAdmin SQL Dump
-- version 4.0.4.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: May 23, 2017 at 05:39 AM
-- Server version: 5.5.32
-- PHP Version: 5.4.19

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `pelanggan`
--
CREATE DATABASE IF NOT EXISTS `pelanggan` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `pelanggan`;

-- --------------------------------------------------------

--
-- Table structure for table `kategori`
--

CREATE TABLE IF NOT EXISTS `kategori` (
  `id_kategori` int(11) NOT NULL,
  `nama_kategori` varchar(255) NOT NULL,
  `nama_pelanggan` varchar(30) NOT NULL,
  `alamat` varchar(30) NOT NULL,
  `no_telp` char(15) NOT NULL,
  PRIMARY KEY (`id_kategori`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `kategori`
--

INSERT INTO `kategori` (`id_kategori`, `nama_kategori`, `nama_pelanggan`, `alamat`, `no_telp`) VALUES
(1, 'Gamis Syar''i', 'prillaazz', 'Jl . melati', '081575134705'),
(2, 'Gamis Broklat', 'Merdini', 'Jl. anggrek', '089786456222'),
(3, 'Gamis Katun Jepang', 'Bella', 'Jl. kamboja', '085677433211'),
(4, 'Gamis Dubai', 'Nina zatulini', 'Jl. mawar', '081670098732'),
(5, 'Gamis Blazer', 'Cesa Den Riva', 'Jl. sepatu', '08567000023'),
(6, 'Gamis Baloteli', 'selena', 'Jl. lili', '08177856463'),
(7, 'Gamis Tipicos', 'menik', 'Jl. tulip', '083456876900');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
